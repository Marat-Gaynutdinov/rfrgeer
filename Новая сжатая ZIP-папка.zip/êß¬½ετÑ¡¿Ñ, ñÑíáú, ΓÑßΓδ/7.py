date = '2025-12-31'

day, month, year = date.split('-')

date_tuple = (day, month, year)
print(date_tuple)
num = int(input("Введите число: "))

if num % 2 == 0:
    print("Число четное")
else:
    print("Число нечетное")
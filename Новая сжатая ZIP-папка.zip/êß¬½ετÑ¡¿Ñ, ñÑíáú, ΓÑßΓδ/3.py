num = int(input("Введите число: "))

count = len(str(abs(num)))
print("Количество цифр в числе:", count)
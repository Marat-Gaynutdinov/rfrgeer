dct1 = {
  'a': 1,
  'b': 2,
}
dct2 = {
  'c': 3,
  'd': 4,
}

dct_merged = dct1.copy()
dct_merged.update(dct2)
print(dct_merged)
strings = ['1', '2', '3', '4', '5']

numbers = [int(num) for num in strings]
sum_of_numbers = sum(numbers)

print("Сумма элементов списка:", sum_of_numbers)
numbers = [1, 2, 3, 4, 5]

sum_of_numbers = sum(numbers)
print("Сумма элементов списка:", sum_of_numbers)